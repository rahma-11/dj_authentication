# Authentication Project

## USAGE

```bash
git clone https://github.com/Shymaa2611/dj_Authentication.git
cd dj_Authentication
pip install -r requirements.txt
python manage.py runserver
```